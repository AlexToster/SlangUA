import { useEffect, useRef } from 'react';
import { X, ChevronDown, ChevronUp } from 'lucide-react';
import type { Style, SlangStyle } from '../types/api';
import clsx from 'clsx';
import './StyleSelector.css';

interface StyleSelectorProps {
  styles: Style[];
  selectedStyle: SlangStyle | null;
  onSelect: (style: SlangStyle) => void;
  isOpen: boolean;
  onToggle: (open: boolean) => void;
}

export function StyleSelector({ styles, selectedStyle, onSelect, isOpen, onToggle }: StyleSelectorProps) {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const sheetRef = useRef<HTMLDivElement>(null);

  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (buttonRef.current && !buttonRef.current.contains(event.target as Node) &&
          sheetRef.current && !sheetRef.current.contains(event.target as Node)) {
        onToggle(false);
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onToggle]);

  // Focus management
  useEffect(() => {
    if (isOpen) {
      // Focus first item or selected item
      const firstItem = sheetRef.current?.querySelector('[data-style-id]') as HTMLElement;
      firstItem?.focus();
    } else {
      buttonRef.current?.focus();
    }
  }, [isOpen]);

  const handleKeyDown = (event: React.KeyboardEvent, styleId: SlangStyle) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      onSelect(styleId);
      onToggle(false);
    } else if (event.key === 'Escape') {
      onToggle(false);
    }
  };

  const selectedStyleObj = styles.find(s => s.id === selectedStyle);

  return (
    <div className="style-selector">
      <button
        ref={buttonRef}
        className={clsx('style-selector-button', isOpen && 'open')}
        onClick={() => onToggle(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        aria-label={`Вибраний стиль: ${selectedStyleObj?.title || 'не вибрано'}`}
      >
        <span className="style-selector-label">
          {selectedStyleObj?.title || 'Стиль'}
        </span>
        {isOpen ? <ChevronUp className="style-selector-icon" /> : <ChevronDown className="style-selector-icon" />}
      </button>

      {isOpen && (
        <div
          ref={sheetRef}
          className="style-selector-sheet"
          role="listbox"
          aria-label="Оберіть стиль перекладу"
        >
          <div className="style-selector-sheet-header">
            <h3>Оберіть стиль</h3>
            <button
              className="style-selector-close"
              onClick={() => onToggle(false)}
              aria-label="Закрити"
            >
              <X size={20} />
            </button>
          </div>
          <div className="style-selector-list">
            {styles.map((style) => (
              <button
                key={style.id}
                className={clsx('style-selector-item', style.id === selectedStyle && 'selected')}
                role="option"
                aria-selected={style.id === selectedStyle}
                data-style-id={style.id}
                onClick={() => {
                  onSelect(style.id);
                  onToggle(false);
                }}
                onKeyDown={(e) => handleKeyDown(e, style.id)}
              >
                <span className="style-selector-item-title">{style.title}</span>
                {style.id === selectedStyle && (
                  <span className="style-selector-check" aria-hidden="true">✓</span>
                )}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}