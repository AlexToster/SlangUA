# Style Engine Specification

**Статус:** Затверджено до реалізації. 

---

## 0. Контекст перед стартом

`src/services/ai/base.adapter.ts` містить усі 5 стилів (`GEN_Z`, `STREET`, `IT_SLANG`, `POFENI`, `KANCLER`) як один хардкод-об'єкт у `buildSystemPrompt()`, без прикладів, без forbidden-списків, без реєстру.

Виявлено конкретний, підтверджений факт, що обґрунтовує forbidden-механізм (не гіпотеза): словники `STREET` і `POFENI` в поточному коді вже перетинаються — `хата`, `братва`, `бабло`, `базар`/`базарити`, `авторитет` присутні в обох. Це перший worklist-пункт після міграції (розділ 6).

---

## 1. Філософія

SlangUA — не буквальний перекладач, а сервіс із вираженим WOW-ефектом: максимально трансформувати форму тексту, повністю зберігаючи зміст. Стиль має бути миттєво впізнаваним.

Стилі **не рівносильні за ступенем трансформації** — це навмисно:

| Стиль | Характер трансформації |
|---|---|
| `KANCLER` | Навмисно бюрократичний, може роздувати текст у 2–4 рази |
| `GEN_Z` | Молодіжний, довжина речення приблизно зберігається |
| `IT_SLANG` | Технічний жаргон, без молодіжного сленгу |
| `STREET` | Вулична розмовна мова, без "зонової" лексики |
| `POFENI` | Кримінальний жаргон, не змішується зі `STREET` |

Мета кожного стилю: власний Voice, приклади трансформацій, характерний словник, список забороненої лексики — так, щоб стилі були максимально контрастними один до одного.

---

## 2. Архітектура: де саме сидить Style Engine

**Це найважливіше рішення цієї специфікації — воно явно розв'язує розбіжність між двома попередніми документами.**

Style Engine — окремий модуль (`src/style-engine/`), **єдина точка входу якого викликається лише зсередини `BaseAdapter.buildSystemPrompt()`**.

- `TranslationService`, `AIService`, `ProviderFactory` — **жодних змін, жодних нових імпортів**. Вони й далі викликають `aiService.translate({ text, style })` рівно так само, як зараз.
- З точки зору API, БД і клієнта — нічого не змінюється.
- Концептуально Style Engine — незалежна підсистема (дані: prompt/examples/lexicon), але технічно це **бібліотека, яку споживає `base.adapter.ts`**, а не новий вузол у ланцюжку викликів `TranslationService → AIProvider`.

```
Translation Service
        │
        ▼
   AIService / ProviderFactory      ← без змін
        │
        ▼
   BaseAdapter.buildSystemPrompt(style)
        │
        ▼
   Style Engine (loadStyle(style))   ← НОВЕ, викликається звідси, і тільки звідси
        │
        ├── Registry
        ├── base-rules.md
        ├── prompt.md
        ├── examples.json
        └── lexicon.json
        │
        ▼
   готовий system prompt → далі як зараз (адаптер викликає LLM)
```

`base.adapter.ts` перестає знати конкретні стилі — жодного `if style == GEN_Z`, жодного хардкод-об'єкта. Він лише викликає `loadStyle(style)` і отримує готовий об'єкт (не рядок — див. п. 3.1).

### 2.1 Ownership — межі відповідальності

Style Engine відповідає **лише** за:
- завантаження стилю (з поточного джерела — файлової системи);
- збірку system prompt.

Style Engine **не** відповідає за: виклик LLM, кеш перекладів, БД, публічний API, історію перекладів, будь-яку бізнес-логіку `TranslationService`. Порушення цих меж під час реалізації (наприклад, якщо loader.ts почне звертатись до Prisma) — сигнал зупинитись і повернутись до цієї специфікації, а не продовжувати.

### 2.2 Age-restricted styles — dual enforcement

**Важливо:** Перевірка вікових обмежень відбувається в **ДВОХ** місцях:

1. **GET /styles** — фільтрує список стилів, які показуються користувачеві в UI. Повертає лише стилі, де `enabled: true` І (`ageRestricted: false` АБО `user.ageConfirmedAdult === true`).

2. **TranslationService** (перед викликом AI провайдера) — **незалежно перевіряє** `ageRestricted` обраного стилю проти `user.ageConfirmedAdult`. Якщо стиль обмежений, а користувач не підтвердив повноліття — повертає `403 AGE_RESTRICTED_STYLE`.

Друга перевірка обов'язкова, бо клієнт може викликати `POST /translate` безпосередньо з `id` обмеженого стилю, навіть якщо UI його не показує (наприклад, через маніпуляцію запитом). Тільки фільтрація в `GET /styles` **недостатня** для безпеки.

---

## 3. Структура директорій

```
src/
  style-engine/
    registry.json
    base-rules.md          ← спільний базовий блок, читається loader.ts РІВНО ОДИН РАЗ
    loader.ts              ← loadStyle(styleId): Promise<LoadedStyle> (єдина точка читання FS)
    styles/
      gen_z/
        prompt.md
        examples.json
        lexicon.json
      street/
        prompt.md
        examples.json
        lexicon.json
      it_slang/
        prompt.md
        examples.json
        lexicon.json
      pofeni/
        prompt.md
        examples.json
        lexicon.json
      kancler/
        prompt.md
        examples.json
        lexicon.json
```

`base-rules.md` contains the English base prompt for Ukrainian input and Ukrainian slang output. It is validated and loaded once into the immutable Style Engine snapshot, then placed as the first block before every style-specific `systemPrompt`. It is not duplicated in any style `prompt.md`.

---

## 3.1 Контракт `loader.ts`
interface LoadedStyle {
  systemPrompt: string;
}
function loadStyle(styleId: string): Promise<LoadedStyle>;
**Порядок збірки systemPrompt всередині loadStyle (фіксований, не вигадувати інший):**
0. Прочитати `base-rules.md` — це **перший блок**.
1. Нормалізувати `styleId`: привести до нижнього регістру перед пошуком у `registry.json` (значення enum в API/Prisma — ВЕЛИКИМИ літерами: `GEN_Z`, `STREET`, `IT_SLANG`, `POFENI`, `KANCLER`; ключі `registry.json` — малими: `gen_z`, `street`, `it_slang`, `pofeni`, `kancler`).
2. Прочитати `registry.json`, знайти запис за нормалізованим `styleId`. Якщо `enabled: false` або запису немає — кинути `Error`, повідомлення якого містить **і сирий, і нормалізований** `styleId`.
3. Прочитати `styles/<styleId>/prompt.md` — це основа `systemPrompt`.
4. Прочитати `styles/<styleId>/lexicon.json`, взяти лише масив `preferred`. Додати до промпту рядком: `Використовуй слова: ${preferred.join(', ')}`.
5. Прочитати `styles/<styleId>/lexicon.json`, масив `forbidden`. Додати рядком: `Уникай слів: ${forbidden.join(', ')}`.
6. Прочитати `styles/<styleId>/examples.json`. Додати кожен приклад у форматі: `Приклад: "${before}" → "${after}"`.
7. З'єднати всі частини (1 порожній рядок між блоками) і повернути `{ systemPrompt }`.
Жодних інших джерел тексту, жодного зчитування файлів поза цим списком (фіксований набір: `base-rules.md`, `registry.json`, `styles/<styleId>/prompt.md`, `styles/<styleId>/lexicon.json`, `styles/<styleId>/examples.json`).
---

## 4. Формат файлів

### `registry.json`

```json
{
  "gen_z":    { "id": "gen_z",    "title": "Gen Z",     "enabled": true, "ageRestricted": false, "version": "1.0" },
  "street":   { "id": "street",   "title": "Street",    "enabled": true, "ageRestricted": false, "version": "1.0" },
  "it_slang": { "id": "it_slang", "title": "IT Slang",  "enabled": true, "ageRestricted": false, "version": "1.0" },
  "pofeni":   { "id": "pofeni",   "title": "Pofeni",    "enabled": true, "ageRestricted": true,  "version": "1.0" },
  "kancler":  { "id": "kancler",  "title": "Kancler",   "enabled": true, "ageRestricted": false, "version": "1.0" }
}
```

`id` дублює ключ об'єкта навмисно — при переході на БД записи матимуть стабільний первинний ідентифікатор незалежно від структури, що його зберігає.

**`ageRestricted` (обов'язкове поле, boolean)** — вказує, чи є стиль віковим обмеженим (18+).
- `true` — стиль доступний лише користувачам, які підтвердили повноліття через `ageConfirmedAdult: true` у профілі.
- `false` — стиль доступний всім користувачам.
- Це поле **має бути явно вказане для кожного стилю** (ніколи не вилучати, не залежати від значення за замовчуванням). Відсутність поля вважається помилкою конфігурації.

Використання в майбутньому (не зараз): вимкнення стилю, beta/premium-позначки — без зміни коду.

### `prompt.md`

Тільки опис стилю, без коду:
- **Voice** — хто "говорить" у цьому стилі
- **Tone** — загальний настрій
- **Transformation Rules** — наскільки сильно й як саме трансформується текст (для `KANCLER` тут явно фіксується "2–4x довжини"; для `GEN_Z` — "довжина приблизно зберігається")
- **Avoid** — чого уникати текстово (доповнює, не замінює `lexicon.forbidden`)

### `examples.json`

```json
[
  { "before": "...", "after": "..." }
]
```

Зараз — 0 прикладів для всіх стилів (реальний поточний стан). Мінімум для старту цього рефакторингу — **3 приклади на стиль**, обов'язково включно з демонстрацією `KANCLER`-подовження (щоб показати структурну трансформацію, не лише заміну слів). Подальше зростання: 3 → 50 → 100 → 300, поступово, не зараз.

### `lexicon.json` (об'єднаний формат)

```json
{
  "preferred": ["крінж", "вайб", "база"],
  "forbidden": ["общак", "пахан", "малява"]
}
```

Один файл замість окремих `vocabulary.json`/`forbidden.json` — preferred і forbidden тісно пов'язані, і перевірка "слово не входить одночасно в обидва списки" природньо робиться в межах одного файлу.

**Жорсткий guardrail:** `preferred` — **20–40 найхарактерніших слів**, не звалище. Поточні хардкод-списки вже перевищують 20–40 слів для `GEN_Z` (~70), `STREET` (~85), `IT_SLANG` (~130), `POFENI` (~80) — не лише `POFENI`. Звуження до 20–40 найхарактерніших слів застосовується до **ВСІХ 5 стилів** під час Кроку 2б, а не лише до `POFENI`.

---

## 5. Що НЕ робимо зараз (Version 2 — свідомо відкладено)

- `config.yaml`/`config.json` для стилю (`max_length_change`, `density`, `emoji_policy`, `aggression_level`)
- Prompt Builder (автоскладання фінального промпту з компонентів)
- Character Engine (перехід від "стилю" до "персонажа")
- Adaptive Examples (динамічний вибір релевантних прикладів під конкретне речення)
- Style Validation (автотести на forbidden-слова в реальному output моделі)

Причина та сама: архітектура ще формується, передчасна абстракція коштує дорожче, ніж її відсутність.

---

## 5.1 Майбутнє: незалежність від сховища (не реалізовувати зараз)

Це принцип для інтерфейсу, а не завдання на реалізацію — не суперечить розділу 5 (жодного `StorageProvider`, жодного repository-патерну зараз).

Єдина вимога зараз: публічний контракт `loadStyle(styleId): Promise<LoadedStyle>` (п. 3.1) не повинен приймати файлові шляхи чи будь-які FS-специфічні параметри, і жоден виклик ззовні `loader.ts` не повинен покладатись на те, що джерело — саме файлова система.

Поточне джерело даних — файлова система. У майбутньому джерелом можуть стати БД, зовнішній API або адмін-панель. Перехід на інше сховище не повинен вимагати зміни сигнатури `loadStyle()` чи будь-чого в `BaseAdapter` — саме тому `Promise` в сигнатурі зафіксований вже зараз (п. 3.1), а не додається пізніше.

---

## 6. Гарантії сумісності
- Стилі й далі живуть у файловій системі; `SlangStyle` enum у БД не змінюється.
- Контракт `POST /translate` (`style` як enum-string) незмінний.
- Сам refactor Style Engine не змінює наведені нижче файли:
  - `src/services/translation.service.ts`
  - `src/services/ai/ai.service.ts`
  - `src/services/ai/provider.factory.ts`
  - `src/routes/*.ts`
  - `prisma/schema.prisma`
- **Документований виняток — age-restricted styles:** для `POFENI` додано продуктову self-attestation `User.ageConfirmedAdult`, міграцію та server-side enforcement у `TranslationService` і маршрутах User/Styles. Це не змінює enum або формат `POST /translate`, але є необхідною інтеграцією age gate, а не частиною file-based loader refactor.
- **Fallback (рішення зафіксовано, не переглядати в межах цього рефакторингу):** `loadStyle()` **НІКОЛИ** не робить мовчазного fallback на `GEN_Z`; невідомий або вимкнений стиль **завжди кидає помилку**, яку викликач у `BaseAdapter` ловить і перетворює на відповідь `400` зі списком доступних стилів. Це **свідома зміна поведінки** порівняно з поточним кодом (`stylePrompts[style] || stylePrompts.GEN_Z`), а не перенесення як є.
---

## 7. Порядок міграції (для виконавчого промпту)
Виконувати строго послідовно. Після кожного кроку — виконати "Перевірку" перед переходом далі.
**Крок 1. Створити структуру директорій і `registry.json`.**
Створити `src/style-engine/registry.json` (вміст — з розділу 4), `src/style-engine/base-rules.md` (вміст — поточний `basePrompt` з `buildSystemPrompt()` у `base.adapter.ts`) і порожні файли-заглушки `src/style-engine/styles/<id>/{prompt.md,examples.json,lexicon.json}` для всіх 5 стилів (`gen_z, street, it_slang, pofeni, kancler`).
*Перевірка:* `find src/style-engine -type f | wc -l` → має бути 17 (1 registry.json + 1 base-rules.md + 5×3).
**Крок 2а. Механічно перенести текст 5 стилів (без редагування змісту).**
Скопіювати текст кожного стилю з `stylePrompts` у `base.adapter.ts` у відповідний `prompt.md` (описова частина) і `lexicon.json.preferred` (перелік слів), рівно як є, без скорочень.
*Перевірка:* кожен `lexicon.json` не порожній; `prompt.md` не порожній для всіх 5 стилів.
**Крок 2б. Звузити словники для всіх 5 стилів (окремо від 2а, після нього).**
У `lexicon.json.preferred` кожного з 5 стилів залишити лише 20–40 найхарактерніших слів. Приклад достатнього набору для POFENI (можна використати як є):
`шконка, параша, зона, кича, шизо, пахан, авторитет, малява, общак, кум, вертухай, стукач, фраєр, лох, понятія, по понятіям, пред'ява, рамси, наїзд, розборка, кидала, заточка, ґрєв, пайка, лаве, зелень, капуста, зашквар, фуфло`.
Приклади для решти стилів (за аналогією з POFENI):
- `GEN_Z`: `крінж, вайб, база, рофл, краш, сигма, скул, агріться, чилити, флекс, хайп, лол, кек, токсик, душніла, ізі, катка, шеймити, крашнути, збс`.
- `STREET`: `хата, бабло, базар, розклад, стрілка, кент, кореш, шухер, метушня, розрулити, нарисуватись, по-братськи, земляк, свояк, розводка, наїзд, розборка, кидала, фуфло, зашквар`.
- `IT_SLANG`: `деплой, комміт, мердж, фіча, баг, хотфікс, рефакторинг, легасі, прод, дев, стейдж, локально, задеплоїти, закоммітити, змерджити, роадмап, спринт, беклог, код-рев'ю, пайплайн`.
- `KANCLER`: `згідно, відповідно, у зв'язку, беручи до уваги, вищевикладене, чинний, порядок, розгляд, звернення, термін, надати, забезпечити, здійснити, вжити, заходів, у визначений, на підставі, керуючись, повідомляємо, просимо`.
*Перевірка:* `preferred.length` для **кожного** з 5 стилів між 20 і 40.
**Крок 3. Розвести перетин STREET↔POFENI за таблицею (фіксована, не вигадувати іншу):**
| Слово | Preferred у | Forbidden у |
|---|---|---|
| хата | street | pofeni |
| братва | pofeni | street |
| бабло | street | pofeni |
| базар, базарити | pofeni | street |
| авторитет | pofeni | street |
Для кожного рядка: прибрати слово з `preferred` "programного" стилю (якщо там є) і додати в `forbidden` того стилю, де стоїть "Forbidden у".
*Перевірка:* жодне слово з лівої колонки не входить у `preferred` обох стилів одночасно.
**Крок 4. Додати приклади в `examples.json` (мінімум 3 на стиль).**
Еталонний приклад для KANCLER (щоб зафіксувати рівень і формат — інші стилі за аналогією):
```json
[{ "before": "Дай мені відповідь.", "after": "Прошу надати вичерпну відповідь у визначений термін, беручи до уваги вищевикладені обставини та відповідно до чинного порядку розгляду звернень." }]

Перевірка: кожен examples.json містить масив довжиною ≥ 3, кожен елемент має непорожні before і after.

Крок 5. Реалізувати loader.ts за порядком збірки з §3.1. Перевірка: await loadStyle('GEN_Z') повертає { systemPrompt: string }, systemPrompt.length > 0; await loadStyle('gen_z') також працює (регістронезалежно завдяки нормалізації з кроку 1).

Крок 6. Замінити виклик у BaseAdapter.buildSystemPrompt() на loadStyle(style), видалити хардкод-об'єкт stylePrompts. Перевірка: grep -c "GEN_Z:" src/services/ai/base.adapter.ts → 0.

Крок 7. Спочатку запустити `npm test`: він перевіряє production build, packaging Style Engine assets, усі 5 стилів, регістронезалежність і disabled-гілку. Після цього вручну запустити backend (`npm run dev`) і для кожного з 5 стилів виконати POST /api/v1/translate (curl або файли з test/translate-request.json як шаблон запиту, підставляючи кожен style). Перевірка: усі 5 запитів повертають 200 з непорожнім translatedText.
---

## 8. Definition of Done
 
  - [x] grep -c "GEN_Z:" src/services/ai/base.adapter.ts → 0
  - [x] find src/style-engine/styles -mindepth 1 -maxdepth 1 -type d | wc -l → 5
  - [x] registry.json існує і містить усі 5 id
  - [x] loadStyle() — єдина функція, що читає файли style-engine (перевірено вручну: жоден інший файл не імпортує fs/path для style-engine/)
  - [x] Жодне слово з таблиці Кроку 3 не входить у preferred обох стилів одночасно
  - [x] Кожен examples.json має ≥ 3 приклади з непорожніми before/after
  - [ ] Ручна перевірка Кроку 7 пройдена для всіх 5 стилів (200, непорожній результат) — не перевірено (backend не запускався)
  - [x] Зміни поза loader refactor обмежені документованим age-gate винятком у §6
  - [x] Production build містить усі Style Engine assets; усі 5 стилів, case-insensitive lookup, unknown style та disabled `pofeni` перевіряються `npm test` через `test/verify-style-engine.mjs`
  - [x] base-rules.md існує, не порожній, і його вміст присутній на початку кожного зібраного systemPrompt — перевіряється `npm test` через `test/verify-style-engine.mjs`
  - [x] preferred.length між 20 і 40 для КОЖНОГО з 5 стилів, не лише pofeni (gen_z:39, street:38, it_slang:40, pofeni:39, kancler:32)
  - [x] `npm test` тепер перевіряє: production build + runtime Style Engine behavior (test:smoke) + детерміновані HTTP інтеграційні тести (test:integration) через Vitest + Testcontainers + локальний mock Ollama
  - [x] Реальні AI-провайдери (OpenAI, Anthropic, Gemini, Ollama) **не викликаються** в тестах; якість реальних провайдерів не тестувалася
