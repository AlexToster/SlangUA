import { FastifyRequest, FastifyInstance, FastifyReply, FastifyError, FastifyPluginAsync } from 'fastify';

const request: FastifyRequest = {} as any;
const instance: FastifyInstance = {} as any;
const reply: FastifyReply = {} as any;
const error: FastifyError = {} as any;
const plugin: FastifyPluginAsync = async () => {};

console.log(request, instance, reply, error, plugin);
